configuration ExecuteScript
{

    Param 
    (
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,

        [Parameter(Mandatory=$true)]
        [String]$DCvmName,

        [Parameter(Mandatory=$true)]
        [String]$CAName,
    
        [Parameter(Mandatory=$true)]
        [String]$CDPURL,
    
        [Parameter(Mandatory=$true)]
        [String]$WebenrollURL,

        [Parameter(Mandatory=$true)]
        [String]$demoCertDNSName
    )

    [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)
    
    Node localhost
    {
  
    
        script 'ExecuteScript'
        {
            PsDscRunAsCredential = $DomainCreds
            GetScript       = { return @{result = 'result'} }
            TestScript      = { return $false }
            SetScript       = {

                # create a local folder named c:\temp\script and copy the "https://raw.githubusercontent.com/fabmas/certlc/main/.scripts/InstallEntRootCA.ps1" file into it
                $ScriptFolder="c:\temp\script"
                New-Item -Path $ScriptFolder -ItemType Directory -Force |Out-Null
                $ScriptName="InstallEntRootCA.ps1"
                $ScriptPath="$ScriptFolder\$ScriptName"
                $ScriptURL="https://raw.githubusercontent.com/fabmas/certlc/main/.scripts/InstallEntRootCA.ps1"
                Invoke-WebRequest -uri $ScriptURL -OutFile $ScriptPath

                # then run the following command to execute the script
                #Start-Process -FilePath "powershell.exe " -ArgumentList "-File $ScriptPath $CAName $CDPURL $WebenrollURL $demoCertDNSName" -Verbose

                # $a = @()
                # $a += ("-CAName", "DEMOCA")
                # $a += ("-CDPURL", $CDPURL)
                # $a += ("-WebenrollURL", $WebenrollURL)
                # $a += ("-demoCertDNSName", $demoCertDNSName)

                #Invoke-Expression "$ScriptPath $a"
                Invoke-Expression "$ScriptPath -DCvmName DC01 -CAName DEMOCA -CDPURL http://ca01.demo.local -WebenrollURL http://ca01.demo.local -demoCertDNSName prova.democa.local"

                #Invoke-Command -ComputerName $env:COMPUTERNAME -FilePath $ScriptPath -Credential $SecureCreds -ArgumentList $CAName,$CDPURL,$WebenrollURL,$demoCertDNSName -Verbose

            
            }            
        }
    
    } 


}